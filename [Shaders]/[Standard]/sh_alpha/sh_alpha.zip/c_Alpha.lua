

addEventHandler( "onClientResourceStart",resourceRoot,
    function (  )
		alphaShader = dxCreateShader ( "shaders/shader_Alpha.fx",0,0,false,'object,ped,vehicle' )

		applyList = {'*clouds*','*Atmosphere*','*galaxy*','*marine_helmet_hud*','LightBeam','*glass*','*volumetric dust*','teleporter_shield_mask'}

		for i,v in pairs(applyList) do
			engineApplyShaderToWorldTexture(alphaShader,v,nil,false)
		end
    end
);